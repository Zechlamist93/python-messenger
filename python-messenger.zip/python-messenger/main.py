from flask import (
    Blueprint,
    render_template,
    request,
    session,
    redirect,
    jsonify,
    url_for,
)
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os



# ---------------------------------------------------------
# Messenger-Blueprint
# ---------------------------------------------------------

messenger = Blueprint(
    "messenger",
    __name__,
    template_folder=os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "templates"
    ),
    url_prefix="/python-messenger",
)


# ---------------------------------------------------------
# Datenbank
# ---------------------------------------------------------

def get_db_path():
    return os.path.join(os.path.dirname(__file__), "messenger.db")


def init_db():
    db_path = get_db_path()

    conn = sqlite3.connect(db_path)

    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)
        conn.commit()
    finally:
        conn.close()


# Vorläufig weiterhin im Arbeitsspeicher.
# Später sollte die Nachrichtenhaltung ebenfalls über SQLite erfolgen.
messages = []


# ---------------------------------------------------------
# Registrierung
# ---------------------------------------------------------

@messenger.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        password_hash = generate_password_hash(password)

        conn = sqlite3.connect(get_db_path())

        try:
            conn.execute(
                """
                INSERT INTO users (username, password_hash)
                VALUES (?, ?)
                """,
                (username, password_hash),
            )
            conn.commit()

            session["username"] = username

            return redirect(url_for("messenger.home"))

        except sqlite3.IntegrityError:
            return "Username already exists", 400

        finally:
            conn.close()

    return render_template("messenger/register.html")


# ---------------------------------------------------------
# Login
# ---------------------------------------------------------

@messenger.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect(get_db_path())

        try:
            user = conn.execute(
                """
                SELECT username, password_hash
                FROM users
                WHERE username = ?
                """,
                (username,),
            ).fetchone()
        finally:
            conn.close()

        if user and check_password_hash(user[1], password):
            session["username"] = user[0]
            return redirect(url_for("messenger.home"))

        return "Invalid username or password", 401

    return render_template("messenger/login.html")


# ---------------------------------------------------------
# Logout
# ---------------------------------------------------------

@messenger.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("messenger.home"))


# ---------------------------------------------------------
# Messenger-Startseite
# ---------------------------------------------------------

@messenger.route("/", methods=["GET", "POST"])
def home():
    username = session.get("username")

    if request.method == "POST":

        if "username" in request.form:
            username = request.form["username"]
            session["username"] = username
            return redirect(url_for("messenger.home"))

        if "message" in request.form:
            message = request.form["message"]
            username = session.get("username", "unknown")

            messages.append({
                "username": username,
                "message": message,
            })

            return redirect(url_for("messenger.home"))

    return render_template(
        "messenger/index.html",
        messages=messages,
        username=username,
    )


# ---------------------------------------------------------
# Nachrichten abrufen
# ---------------------------------------------------------

@messenger.route("/messages")
def get_messages():
    return jsonify(messages)
